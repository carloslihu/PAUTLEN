Este es el arbol de directorios:
	Makefile	
	README.txt

	includes/
		tablaHash.h
		tablaSimbolos.h
	
	obj/
		(contendrá los .o generados con el makefile)
	
	src/
		prueba_tabla.c
		tablaHash.c
		tablaSimbolos.c

	txt/
		input.txt (fichero de prueba para el ejecutable)

